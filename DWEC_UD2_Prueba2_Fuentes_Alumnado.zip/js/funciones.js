"use strict";

// EJERCICIO 1: completa la función utilizando while.
function contarDigitosPares(numero) {
    // TODO: escribe aquí tu código.
}

// EJERCICIO 2: completa la función utilizando for.
function sumaAlterna(limite) {
    // TODO: escribe aquí tu código.
}
