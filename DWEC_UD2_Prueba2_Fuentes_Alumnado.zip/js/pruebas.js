"use strict";

// EJERCICIO 3: BANCO DE PRUEBAS
// Programa la comparación de resultados y su visualización.
function probar(descripcion, obtenido, esperado) {
    // TODO: comparar obtenido con esperado y mostrar CORRECTO/ERROR.
}

// Programa las 8 pruebas: 6 obligatorias y 2 propias.
function ejecutarPruebas() {
    // TODO: limpiar la salida anterior y ejecutar las 8 pruebas.
}

// TODO: conectar el botón btnPruebas con ejecutarPruebas().
